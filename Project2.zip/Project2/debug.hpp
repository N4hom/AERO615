#ifndef DEBUG_
#define DEBUG_ 

bool DEBUG = true;


#endif